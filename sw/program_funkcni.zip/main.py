from array import array
import board
import displayio
import framebufferio
import rgbmatrix
from digitalio import DigitalInOut,Direction
import adafruit_display_text.label
import terminalio
from adafruit_bitmap_font import bitmap_font
import time
from math import sin
import analogio
from digitalio import DigitalInOut, Direction, Pull
import random as rd

#audio
fft_size = 256  # Sample size for Fourier transform, MUST be power of two
spectrum_size = fft_size // 2  # Output spectrum is 1/2 of FFT result
# Bottom of spectrum tends to be noisy, while top often exceeds musical
# range and is just harmonics, so clip both ends off:
# Original low = 10 and high = 75
low_bin = 20
high_bin = 40  # Highest bin "



#pins definition
adca = analogio.AnalogIn(board.GP26)
adcb = analogio.AnalogIn(board.GP27)
prv = DigitalInOut(board.GP0)
nex = DigitalInOut(board.GP1)
prv.direction = Direction.INPUT
nex.direction = Direction.INPUT
prv.pull = Pull.UP
nex.pull = Pull.UP
ct1 = DigitalInOut(board.GP6)
ct2 = DigitalInOut(board.GP7)
ct1.direction = Direction.OUTPUT
ct2.direction = Direction.OUTPUT
ws = DigitalInOut(board.GP3)
lr = DigitalInOut(board.GP4)
ws.direction = Direction.OUTPUT
lr.direction = Direction.OUTPUT
lr.value = False
ws.value = False
### end of pins

menu = 1
num_choices = 4 #pong, fft, snake

bit_depth_value = 3
unit_width = 128
unit_height = 64
chain_width = 1
chain_height = 1
serpentine_value = True

width_value = unit_width*chain_width
height_value = unit_height*chain_height

displayio.release_displays()

matrix = rgbmatrix.RGBMatrix(  #my board pinout
    width = width_value, height=height_value, bit_depth=bit_depth_value,
    rgb_pins = [board.GP9, board.GP8, board.GP10, board.GP12, board.GP11, board.GP14],
    addr_pins = [board.GP16, board.GP15, board.GP18, board.GP17, board.GP13],
    clock_pin = board.GP20, latch_pin=board.GP19, output_enable_pin=board.GP21,
    tile = chain_height, serpentine=serpentine_value,
    doublebuffer = True)

DISPLAY = framebufferio.FramebufferDisplay(matrix, auto_refresh=True,rotation=180)

now = t0 =time.monotonic_ns()
append_flag = 0
def line(x0, y0, x1, y1):
    dx = abs(x1 - x0)
    dy = abs(y1 - y0)
    sx = -1 if x0 > x1 else 1
    sy = -1 if y0 > y1 else 1
    err = dx - dy

    line_points = []

    while x0 != x1 or y0 != y1:
        line_points.append((x0, y0))
        e2 = 2 * err
        if e2 > -dy:
            err -= dy
            x0 += sx
        if e2 < dx:
            err += dx
            y0 += sy

    line_points.append((x0, y0))

    return line_points
class RGB_Api():
    
    READ_SLEEP = 1  #1uS na přepnutí pinů pro ADC
    def __init__(self):

        #Set image
        self.image = 'player_blue.bmp'
        self.image_r = 'player_red.bmp'
        self.ball = 'ball.bmp'
        #Set text
        self.txt_str = "CVUT FEL 2023, LPE"
        #self.txt_color = 0xff0075
        self.txt_color = 0x00ffff
        self.txt_x = 10
        self.txt_y = 58
        self.txt_font = terminalio.FONT
        self.txt_line_spacing = 0.5
        self.txt_scale = 1

        #Set scroll
        self.scroll_speed = 60
        
        if self.txt_font == terminalio.FONT:
            self.txt_font = terminalio.FONT
        else:
            self.txt_font = bitmap_font.load_font(self.txt_font)
        self.B_BITMAP = displayio.OnDiskBitmap(open(self.image, 'rb'))  #blue player
        self.Bplayer = displayio.TileGrid(
            self.B_BITMAP,
            pixel_shader = getattr(self.B_BITMAP, 'pixel_shader', displayio.ColorConverter()),
            width = 1,
            height = 1,
            tile_width = self.B_BITMAP.width,
            tile_height = self.B_BITMAP.height)
        
        self.R_BITMAP = displayio.OnDiskBitmap(open(self.image_r, 'rb'))  #red player
        self.Rplayer = displayio.TileGrid(
            self.R_BITMAP,
            pixel_shader = getattr(self.R_BITMAP, 'pixel_shader', displayio.ColorConverter()),
            width = 1,
            height = 1,
            tile_width = self.R_BITMAP.width,
            tile_height = self.R_BITMAP.height)
        self.BALL_BITMAP = displayio.OnDiskBitmap(open(self.ball, 'rb'))  #ball
        self.ball = displayio.TileGrid(
            self.BALL_BITMAP,
            pixel_shader = getattr(self.BALL_BITMAP, 'pixel_shader', displayio.ColorConverter()),
            width = 1,
            height = 1,
            tile_width = self.BALL_BITMAP.width,
            tile_height = self.BALL_BITMAP.height)
    def limit(self, a ,b): #limits a in range of +b -b
        if(abs(a) < abs(b)):
            return a
        else:
            return b
    def in_pins(self): #function that returns 4 values from two joysticks
        
        x1 = int(adca.value>>3) #fast division of 65k something value 
        x2 = (2<<16)-int(adcb.value>>3)
        ct1.value = True
        time.sleep(self.READ_SLEEP * 1e-6)
        y1 = int(adca.value>>3)
        y2 = int(adcb.value>>3)
        ct1.value = False
        time.sleep(self.READ_SLEEP * 1e-6)
        return [x1,y1,x2,y2]
    def calc_off(self, off_data, raw_data):
        pole = []
        for i, p in enumerate(raw_data):
            pole.append(p - off_data[i])
        return pole
    #@brief:  Display a text in static mode
    #@param:  self
    #@retval: None
    def clean_layers(self, list, group):
        for l in list:
            group.remove(l)
    ############################################################################################
    def ping_pong(self):
        global unit_width;
        global unit_height;
        global menu;
        global num_
        bv = [0.0,0.0] #ball vectors
        layers = []
        off_data = self.in_pins()
        GROUP = displayio.Group()
        GROUP.append(self.Bplayer)
        layers.append(self.Bplayer)
        GROUP.append(self.Rplayer)
        layers.append(self.Rplayer)
        GROUP.append(self.ball)
        layers.append(self.ball)
        
        self.Rplayer.x = unit_width - self.R_BITMAP.width
        self.ball.x = int(unit_width/2)
        self.ball.y = int(unit_height/2)
        
        TEXT = adafruit_display_text.label.Label(
            self.txt_font,
            color = self.txt_color,
            scale = self.txt_scale,
            text = self.txt_str,
            line_spacing = self.txt_line_spacing
            )
        TEXT.x = self.txt_x# self.txt_x
        TEXT.y = self.txt_y
        self.Bplayer.y = int(64/2) - 6
        self.Rplayer.y = int(64/2) - 6
        GROUP.append(TEXT)
        layers.append(TEXT)
        #show the welcome message
        WELCOME = adafruit_display_text.label.Label(
            self.txt_font,
            color = self.txt_color,
            scale = self.txt_scale,
            text = "Pojdte si zahrat",
            line_spacing = self.txt_line_spacing
            )
        WELCOME.x = 17# self.txt_x
        WELCOME.y = 20
        GROUP.append(WELCOME)
        layers.append(WELCOME)
        DISPLAY.show(GROUP)
        DISPLAY.refresh()
        bv[0] = rd.randint(-2,2)
        bv[1] = rd.randint(-2,2)
        if( bv[0] == 0):
            bv[0] = 2
        flag = False
        q = False
        time.sleep(1)
        while not flag:  #wait for input from user
            data = self.calc_off(off_data,self.in_pins())
            if abs(data[0]) > 1000 or abs(data[2]) > 1000:
                flag = True
            if( prv.value == False):
                if(menu > 1):
                    menu -= 1
                    self.clean_layers(layers, GROUP)
                    q = True
                    break
            elif ( nex.value == False):
                if(menu < num_choices ):
                    menu += 1
                    self.clean_layers(layers, GROUP)
                    q = True
                    break
        #clear the welcome message
        GROUP.remove(WELCOME)
        layers.remove(WELCOME)
        while True and not q:
            raw_data = self.calc_off(off_data,self.in_pins()) #compute the movement of joystick
            ## sliding the sliders (blue)
            if self.Bplayer.y + self.B_BITMAP.height < 0:
                self.Bplayer.y = unit_height - self.B_BITMAP.height
                
            elif (self.Bplayer.y  < unit_height):
                self.Bplayer.y += int(raw_data[0]/700) #J4 sideboard X (horiz.)
            else:
                self.Bplayer.y = 0
            ### sliding the sliders (red)    
            if self.Rplayer.y + self.R_BITMAP.height < 0:
                self.Rplayer.y = unit_height - self.R_BITMAP.height
                
            elif (self.Rplayer.y  < unit_height):
                self.Rplayer.y += int(raw_data[2]/700) #J3 sideboard X (horiz.)
            else:
                self.Rplayer.y = 0
            
            ## sliding the ball
            if (self.ball.x-1 < self.B_BITMAP.width and (self.ball.y < (self.Bplayer.y+self.B_BITMAP.height)-1 and (self.ball.y+self.BALL_BITMAP.height)+1 > self.Bplayer.y) ): #ball reaches player blue
                #print(bv[0],bv[1])
                bv[0] = -1*bv[0]
                bv[1] += int(raw_data[0]/500) #add some speed based on speed of the player
                bv[0] += bv[0]/30.0
                bv[1] += bv[1]/30.0
                bv[0] = self.limit(bv[0], 2.5)
                bv[1] = self.limit(bv[1], 2.5)
                time.sleep(0.001)
                                                #koule je u praveho hr  a                           vrsek koule je vys jak spodek hrace                     a spodek koule niz jak vrsek hrace
            elif (self.ball.x+self.BALL_BITMAP.width)+1 > unit_width-self.R_BITMAP.width and (self.ball.y < (self.Rplayer.y+self.R_BITMAP.height)-1 and (self.ball.y+self.BALL_BITMAP.height)-1 > self.Rplayer.y):#ball reaches player red
                bv[0] = -1*bv[0]
                bv[1] += int(raw_data[2]/500)
                bv[0] += bv[0]/30.0
                bv[1] += bv[1]/30.0
                bv[0] = self.limit(bv[0], 2.5)
                bv[1] = self.limit(bv[1], 2.5)
                time.sleep(0.001)
            if (self.ball.x <= 0 or (self.ball.x+self.BALL_BITMAP.width) >= unit_width): #goes past players (end of game)
                #bv[0] = -1*bv[0]
                GME_OVR = adafruit_display_text.label.Label(
                    self.txt_font,
                    color = 0xFF0000,
                    scale = self.txt_scale,
                    text = "GAME OVER",
                    line_spacing = self.txt_line_spacing
                    )
                GME_OVR.x = 35# self.txt_x
                GME_OVR.y = 20
                GROUP.append(GME_OVR)
                time.sleep(2) # "reset" the game
                GROUP.remove(GME_OVR)
                print("ball crashed",self.ball.x, self.ball.y)
                bv[0] = rd.randint(-2,2)
                bv[1] = rd.randint(-2,2)
                if( bv[0] == 0):
                    bv[0] = 2
                self.ball.x = int(unit_width/2)
                self.ball.y = int(unit_height/2)    
            if (self.ball.y <= 0 or (self.ball.y+self.BALL_BITMAP.height) >= unit_height): #ball reaches top or bottom
                bv[1] = -1*bv[1]
            
            
            self.ball.x = self.ball.x + int(bv[0])
            self.ball.y = self.ball.y + int(bv[1])
            #TEXT.text = "x1:"+str(raw_data[0]) + " y1:" +str(raw_data[1])
            #print("x1:%d y1:%d ; x2:%d y2:%d" % (raw_data[0], raw_data[1], raw_data[2], raw_data[3]))
            #DISPLAY.refresh()
            time.sleep(1/30) #fps limit
            
            if( prv.value == False):
                if(menu > 1):
                    menu -= 1
                    self.clean_layers(layers, GROUP)
                    break
            elif ( nex.value == False):
                if(menu < num_choices ):
                    menu += 1
                    self.clean_layers(layers, GROUP)
                    break
                
            pass
    ####################################################################################################
    def fft(self):
        global menu;
        global num_choices;
        
        group = displayio.Group()

        # Create a Bitmap with the same dimensions as the display
        bitmap = displayio.Bitmap(DISPLAY.width, DISPLAY.height, 2) #num at the end are possible colors

        # Create a Palette with appropriate color(s)
        palette = displayio.Palette(2) #num of colors in palette
        palette[0] = 0x000000  # set the n-th color to be specifically this
        palette[1] = 0xFF0000

        # Create a TileGrid using the Bitmap and Palette
        tile_grid = displayio.TileGrid(bitmap, pixel_shader=palette)

        # Set the pixel values to draw a line
        start_x = 10
        start_y = 10
        end_x = 20
        end_y = 20
        
        pix = []
        for col in range(128):
            if col%2 == 0:
                pix = line(col, 63, col, rd.randint(0,63))
            for a,b in pix:
                #print("sour",a+col%2,b)
                bitmap[a+col%2,b] = 1  # Set pixel value to draw the line
        # Append the TileGrid to the Group
        group.append(tile_grid)

        # Show the Group on the display
        DISPLAY.show(group)

        dynamic_level = 0
        while True:
            for col in range(127):
                bST = rd.randint(0,63)
                for row in range(64):
                    if row < bST: #write black
                        bitmap[col,row] = 0
                    else:
                        #write red
                        bitmap[col,row] = 1  # Set pixel value to draw the line
            #time.sleep(0.01)
            
            # Append the TileGrid to the Group
            #print("hello world")
            if( prv.value == False):
                if(menu > 1):
                    menu -= 1
                    group.remove(tile_grid)
                    break
            elif ( nex.value == False):
                if(menu < num_choices ):
                    menu += 1
                    group.remove(tile_grid)
                    break
            time.sleep(0.1)
            
    ###########################################################################################################        
    def snake(self):
        global menu;
        directions = [ (0,-1), (-1,0), (0,1), (1,0) ] 
        LIMIT = 1000
        off_data = self.in_pins()
        length = 1 #original length of snake
        head = [64,32] #initial position of head
        snake = []
        snake.append(head)
        prev_cords = [0, 0]
        d = (1,0) #direction of movement
        layers = []
        ball_size = 3
        dir_changed = 0 #this var ensures the good control of the snake
        bitmap = displayio.Bitmap(DISPLAY.width, DISPLAY.height, 3) #num at the end are possible colors
        GROUP = displayio.Group()
        WELCOME = adafruit_display_text.label.Label(
            self.txt_font,
            color = 0xFF0000,
            scale = self.txt_scale,
            text = "Pojdte si zahrat hada",
            line_spacing = self.txt_line_spacing
            )
        WELCOME.x = 2# self.txt_x
        WELCOME.y = 20
        GROUP.append(WELCOME)
        layers.append(WELCOME)
        DISPLAY.show(GROUP)
        flag = 0
        q = False
        ###    welcome message
        time.sleep(1)
        while not flag:  #wait for input from user
            data = self.calc_off(off_data,self.in_pins())
            if abs(data[0]) > 1000 or abs(data[2]) > 1000:
                flag = True
            if( prv.value == False):
                if(menu > 1):
                    menu -= 1
                    self.clean_layers(layers, GROUP)
                    q = True
                    break
            elif ( nex.value == False):
                if(menu < num_choices ):
                    menu += 1
                    self.clean_layers(layers, GROUP)
                    q = True
                    break
        #clear the welcome message
                
                
        # Create a Palette with appropriate color(s)
        palette = displayio.Palette(3) #num of colors in palette
        palette[0] = 0x000000  # set the n-th color to be specifically this
        palette[1] = 0xFF0000
        palette[2] = 0xFFFF00

        # Create a TileGrid using the Bitmap and Palette
        tile_grid = displayio.TileGrid(bitmap, pixel_shader=palette)

        GROUP.append(tile_grid)
        layers.append(tile_grid)
        DISPLAY.show(GROUP)
        DISPLAY.refresh()
        #drop the treasure (apple) somewhere
        ball = (rd.randint(10, 110), rd.randint(10, 50))
        self.draw_treasure(ball[0], ball[1], ball_size, bitmap)
        while True and not q:
            raw_data = self.calc_off(off_data,self.in_pins()) #reading data from joysticks
            
            
            if(raw_data[0] < -LIMIT and dir_changed == 0): #turn left
                d = directions[(directions.index((d[0], d[1]))+ 1) % 4]
                dir_changed = 1
            if(raw_data[0] > LIMIT and dir_changed == 0): #turn right
                d = directions[(directions.index((d[0], d[1]))- 1) % 4]
                dir_changed = 1
            if(dir_changed == 1 and -LIMIT<raw_data[0]<LIMIT):
                dir_changed = 0
            
            
            if(ball[0] <= head[0] <= ball[0]+ball_size and ball[1] <= head[1] <= ball[1]+ball_size): 
                #the snake touched the ball
                
                self.clean_treasure(ball[0], ball[1], ball_size, bitmap)
                ball = (rd.randint(10, 110), rd.randint(10, 50))
                self.draw_treasure(ball[0], ball[1], ball_size, bitmap)
                
                self.draw_snake(length, snake, bitmap, 1) #clear the snake
                length += 1
                head[0] += d[0] #move in the way of treasure
                head[1] += d[1]
                snake.insert(0, [head[0], head[1]]) #deepcopy
                self.draw_snake(length, snake, bitmap, 0) #show the snake
            else: #normal movement of the snake
                self.draw_snake(length, snake, bitmap, 1) #clear the snake
                head[0] += d[0] #move in the way of treasure
                head[1] += d[1]
                snake.insert(0, [head[0], head[1]]) #deepcopy
                snake.pop()
                self.draw_snake(length, snake, bitmap, 0) #show the snake
            
            if(self.has_duplicates(snake)): #the snake crashed into itself
                time.sleep(1)
                self.clean_treasure(ball[0], ball[1], ball_size, bitmap) #regenerate ball
                ball = (rd.randint(10, 110), rd.randint(10, 50))
                self.draw_treasure(ball[0], ball[1], ball_size, bitmap)
                
                #reset snake
                self.draw_snake(length, snake, bitmap, 1) #clear the snake
                length = 1
                snake = [head]
                self.draw_snake(length, snake, bitmap, 0) #show the snake
                
            if(0>=head[0] or head[0] >= 127 or 0>=head[1] or head[1] >= 63): #the snake reached the edge of field
                time.sleep(1)
                self.clean_treasure(ball[0], ball[1], ball_size, bitmap) #regenerate ball
                ball = (rd.randint(10, 110), rd.randint(10, 50))
                self.draw_treasure(ball[0], ball[1], ball_size, bitmap)
                
                #reset snake
                head[0] = 128//2
                head[1] = 64//2
                self.draw_snake(length, snake, bitmap, 1) #clear the snake
                length = 1
                snake = [head]
                self.draw_snake(length, snake, bitmap, 0) #show the snake
                
                
            if(raw_data[1] > LIMIT): #afterburner
                time.sleep(0.02)
            else:
                time.sleep(0.1)
            if( prv.value == False):
                if(menu > 1):
                    menu -= 1
                    print("layers", layers, GROUP)
                    self.clean_layers(layers, GROUP)
                    break
            elif ( nex.value == False):
                if(menu < num_choices ):
                    menu += 1
                    self.clean_layers(layers, GROUP)
                    break
        #self.clean_layers(layers, GROUP)
    def draw_treasure(self,x,y, size, bitmap):
        for i in range(size):
            for j in range(size):
                bitmap[x+i, y+j] = 2
    def clean_treasure(self,x,y,size,bitmap):
        for i in range(size):
            for j in range(size):
                bitmap[x+i, y+j] = 0
    def draw_snake(self,lenght, snake, bitmap, drclr):
        for i in range(len(snake)):
            if(drclr == 0):
                bitmap[snake[i][0] , snake[i][1]] = 1
            else:
                bitmap[snake[i][0] , snake[i][1]] = 0
    def has_duplicates(self, lst):
        seen = set()
        for item in lst:
            # Convert each sublist to a tuple to make it hashable
            item_tuple = tuple(item)
            if item_tuple in seen:
                return True
            seen.add(item_tuple)
        return False
    def legends(self):
        global menu;
        GROUP = displayio.Group()
        TXT1 = adafruit_display_text.label.Label(
            self.txt_font,
            color = 0xFFFF00,
            scale = self.txt_scale,
            text = "Made by Vit Ruzicka\nduring the LPE \nin 2023 on CVUT FEL\nthx:Fischer, Petrucha",
            line_spacing = 1
            )
        TXT1.x = 2# self.txt_x
        TXT1.y = 10
        layers = []
        off_data = self.in_pins()
        GROUP.append(TXT1)
        layers.append(TXT1)
        DISPLAY.show(GROUP)
        flag = 0
        q = False
        while True:
            if( prv.value == False):
                if(menu > 1):
                    menu -= 1
                    print("layers", layers, GROUP)
                    self.clean_layers(layers, GROUP)
                    break
            elif ( nex.value == False):
                if(menu < num_choices ):
                    menu += 1
                    self.clean_layers(layers, GROUP)
                    break
    def test(self,mode):
        if mode == 1:
            self.ping_pong()
        elif mode == 2:
            self.fft()
        elif mode == 3:
            self.snake()
        elif mode == 4:
            self.legends()

if __name__ == '__main__':
    RGB = RGB_Api()
    GROUP = displayio.Group()
    while True:
        # Number  Function
        #    1    Display pong game
        
        RGB.test(menu) #pong